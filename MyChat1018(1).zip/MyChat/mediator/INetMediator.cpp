#include"INetMediator.h"



INetMediator::INetMediator(){}
INetMediator::~INetMediator(){} //使用时, 父类指针指向子类, 使用虚析构
